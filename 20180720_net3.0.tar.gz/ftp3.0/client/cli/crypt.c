#include "func.h"
int crypt_func(int sfd)
{
	struct spwd *sp;
	char *passwd;
	char salt[512]={0};
	char buf[512]={0};
	char *buf1=NULL;
	printf("1.Login\n");
	printf("2.Register\n");
	read(STDIN_FILENO,buf,sizeof(buf));
	printf("you choose %s\n",buf);
	send(sfd,buf,strlen(buf),0);
	if(strlen(buf)!=0)
	{
		printf("请输入用户名:\n");
		read(STDIN_FILENO,buf,sizeof(buf));//读取用户名
		send(sfd,buf,strlen(buf)-1,0);//发送用户名
		passwd=getpass("请输入密码:");
		recv(sfd,salt,sizeof(salt),0);//接收盐值
		puts(salt);
		buf1=crypt(passwd,salt);//生成密文
		puts(buf1);
		send(sfd,buf1,strlen(buf1),0);//发送密文
		recv(sfd,buf1,sizeof(buf),0);
		puts(buf1);
		while(strstr(buf1,"Login failed")!=NULL)
		{
			printf("Sorry,try again.\n");
			passwd=getpass("请输入密码:");
			send(sfd,"1",1,0);
			recv(sfd,salt,sizeof(salt),0);//接收盐值
			puts(salt);
			buf1=crypt(passwd,salt);//生成密文
			puts(buf1);
			send(sfd,buf1,strlen(buf1),0);//发送密文
			recv(sfd,buf1,sizeof(buf),0);
			printf("%s",buf1);
		}
	}
	return 0;

}
