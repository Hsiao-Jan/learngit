#include "func.h"

int recv_file(int *sfd)
{
	char buf[1000]={0};
	int sfd1=*sfd;
	int len;
	off_t file_size;
	double down_load_size=0;
	char name[128]={0};
	//接文件名
	recv_n(sfd1,(char*)&len,4);
	recv_n(sfd1,buf,len);
	memcpy(name,buf,strlen(buf));
	//接文件大小
	recv_n(sfd1,(char*)&len,4);//每次先取4个字节，是火车头
	recv_n(sfd1,(char*)&file_size,len);
	int fd=open(buf,O_RDWR|O_CREAT,0666);
	check_error(-1,fd,"open");
	//接文件内容
	time_t start,end;
	start=time(NULL);
	end=time(NULL);
	while(1)
	{
		recv_n(sfd1,(char*)&len,4);
		if(len>0)
		{
			recv_n(sfd1,buf,len);
			write(fd,buf,len);
			down_load_size=down_load_size+len;
			end=time(NULL);
			if(end-start>=1)
			{
				printf("%s ->down percent %5.2f%s\r",name,(down_load_size/file_size)*100,"%");
				fflush(stdout);
				start=end;
			}
		}else{
			printf("%s ->down percent success 100%s\n",name,"%");
			break;
		}
	}
	close(fd);
	return 0;
}
