#include "func.h"

int main()
{
	int sfd;
	//初始化socket
	sfd=socket(AF_INET,SOCK_STREAM,0);
	check_error(-1,sfd,"socket");
	struct sockaddr_in ser;
	bzero(&ser,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(2000);
	ser.sin_addr.s_addr=inet_addr("192.168.200.128");
	int ret;
	//请求链接
	ret=connect(sfd,(struct sockaddr*)&ser,sizeof(struct sockaddr));
	check_error(-1,ret,"connect");
	crypt_func(sfd);
	int epfd=epoll_create(1);
	struct epoll_event event,evs[2];
	event.events=EPOLLIN;
	event.data.fd=sfd;
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
	check_error(-1,ret,"epoll_ctl");
	event.data.fd=STDIN_FILENO;
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,STDIN_FILENO,&event);
	check_error(-1,ret,"epoll_ctl1");
	int i;
	char buf[512]={0};
	char buf1[128]={0};
	int ret_num;
	int len;
	while(1)
	{
		ret=epoll_wait(epfd,evs,2,-1);
		check_error(-1,ret,"epoll_wait");
		for(i=0;i<ret;i++)
		{
			if(evs[i].data.fd==sfd)
			{
				bzero(buf,sizeof(buf));
				ret_num=recv(sfd,buf,sizeof(buf),0);
				if(strstr(buf,"ggg")!=NULL)
				{
					recv_file(&sfd);
					break;
				}
				if(ret_num>0)
				{
					printf("%s",buf);
					fflush(stdout);
				}else{
					close(sfd);
					goto end;
				}
			}
			if(evs[i].data.fd==STDIN_FILENO)
			{
				bzero(buf,sizeof(buf));
				read(STDIN_FILENO,buf,sizeof(buf));
				send(sfd,buf,strlen(buf)-1,0);
				if(strstr(buf,"puts")!=NULL)
				{
					len=strlen(buf)-5-1;
					strncpy(buf1,buf+5,len);
					sleep(1);
					tran_file(sfd,buf1);
				}
			}
		}
	}
end:
	printf("byebye\n");	
	close(sfd);
	return 0;
}
