#include "func.h"
int tran_file(int new_fd,char *name)
{
	//发送文件名
	train t;
	t.len=strlen(name);
	strcpy(t.buf,name);
	int ret;
	ret=send_n(new_fd,(char*)&t,4+t.len);
	if(-1==ret)
	{
		goto end;
	}
	int fd=open(name,O_RDONLY);
	check_error(-1,fd,"open");
	//发送文件大小
	struct stat buf;
	fstat(fd,&buf);
	t.len=sizeof(buf.st_size);
	memcpy(t.buf,&buf.st_size,sizeof(off_t));//st_size的类型是off_t
	ret=send_n(new_fd,(char*)&t,4+t.len);
	if(-1==ret)
	{
		goto end;
	}
	//发送文件内容
	while((t.len=read(fd,t.buf,sizeof(t.buf)))>0)
	{
		ret=send_n(new_fd,(char*)&t,4+t.len);
		if(-1==ret)
		{
			goto end;
		}
	}
	send_n(new_fd,(char*)&t,4+t.len);//传输文件的大小不一定是1000，当传输到最后一次t.len==0,就不需要在循环中传了
end:	
	return 0;
}
