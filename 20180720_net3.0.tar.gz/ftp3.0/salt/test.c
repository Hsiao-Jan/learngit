#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <shadow.h>
#include <errno.h>
#include <crypt.h>

int main()
{
	char *buf=NULL;
	buf=crypt("1234","$6$vUlsR1tw");
	printf("%s\n",buf);
}
