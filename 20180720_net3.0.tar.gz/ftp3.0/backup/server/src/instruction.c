#include "factory.h"

int ins_func(pfac pf,pnode_t pq,char *buf,int size)
{
	int len;//此为需要截取的字符串的长度
	char buf1[512]={0};//用来传递其他参数
	if(strstr(buf,pf->a[0])!=NULL)
	{
		len=strlen(buf)-3;
		strncpy(buf1,buf+3,len);
		cd_func(pf,buf1);
	}
	if(strstr(buf,pf->a[1])!=NULL)
	{
		ls_func(pq,pf->path);
	}
	int ret;
	if(strstr(buf,pf->a[2])!=NULL)
	{
		bzero(buf1,sizeof(buf1));
		sprintf(buf1,"%s\n",pf->path);
		printf("%s\n",buf1);
		ret=send(pq->new_fd,buf1,strlen(buf1),0);
		printf("ret=%d\n",ret);
	}
	if(strstr(buf,pf->a[3])!=NULL)
	{
		recv_file(&pq->new_fd);
	}
	if(strstr(buf,pf->a[4])!=NULL)
	{
		len=strlen(buf)-5;
		strncpy(buf1,buf+5,len);
		send(pq->new_fd,"ggg",3,0);
		sleep(1);
		ret=tran_file(pq->new_fd,buf1);
		printf("ret=%d",ret);
	}
	if(strstr(buf,"$")!=NULL)
	{
		crypt_ins(pf,pq->new_fd,buf);
	}
	return 0;
}
