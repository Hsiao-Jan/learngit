#include "factory.h"

void ls_func(pnode_t pq,char *qpath)
{
	if(qpath==NULL)
	{
		printf("error args");
		return;
	}
	DIR *dir;
	dir=opendir(qpath);
	if(dir==NULL)
	{
		perror("opendir");
		send(pq->new_fd,"error args",10,0);
	}
	struct dirent *p;
	struct stat tmp;
	char path[512]={0};
	char buf[512]={0};
	while((p=readdir(dir))!=NULL)
	{
		bzero(buf,sizeof(buf));
		sprintf(path,"%s%s%s",qpath,"/",p->d_name);
		stat(path,&tmp);
		if(!strcmp(p->d_name,".")||!strcmp(p->d_name,".."))
		{
		}else{
			sprintf(buf,"- %-25s%10ld\n",p->d_name,tmp.st_size);
			printf("%s",buf);
			send(pq->new_fd,buf,strlen(buf),0);
		}
	}
	closedir(dir);
}

void cd_func(pfac pf,char *qpath)
{
	int i=strlen(pf->path)-1;
	int len;
	char buf[512]={0};
	if(!strcmp(qpath,".."))
	{
		while(pf->path[i]!='/')
		{
			i--;
		}
		len=i;
		for(i=0;i<len;i++)
		{
			buf[i]=pf->path[i];
		}
		buf[i]='\0';
		printf("%s\n",buf);
		bzero(pf->path,sizeof(factory));
		memcpy(pf->path,buf,strlen(buf));	
	}else{
		strcat(pf->path,"/");
		strcat(pf->path,qpath);
	}	
}

int crypt_ins(pfac pf,int new_fd,char *buf)
{
	struct spwd *sp;
	sp=getspnam("michael");
	if(NULL==sp)
	{
		perror("getspnam");
		return -1;
	}
	if(!strcmp(sp->sp_pwdp,buf))
	{
		send(new_fd,"Login successful\n",18,0);
	}else{
		send(new_fd,"Login failed\n",14,0);
		close(new_fd);
	}
	return 0;
}
