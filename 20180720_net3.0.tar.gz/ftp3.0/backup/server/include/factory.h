#ifndef __FACTORY_H__
#define __FACTORY_H__
#include "head.h"
#include "work_que.h"

typedef void* (*thread_func_t)(void *p);
typedef struct{
	pthread_t *pth_id;//线程id的起始地址
	int pthread_num;//创建的线程数目
	que_t que;//队列
	thread_func_t threadfunc;//线程函数
	pthread_cond_t cond;//线程变量
	short start_flag;//线程启动标志
	char a[6][10];
	char path[1024];
	char name[512];
}factory,*pfac;//线程池的数据结构，小工厂
int factory_init(pfac,thread_func_t,int,int);
int factory_start(pfac);
int tcp_start_listen(int*,char*,char*,int);
int tran_file(int,char*);
int recv_file(int*);
int recv_n(int,char*,int);
int send_n(int,char*,int);
int ins_func(pfac,pnode_t,char*,int);
void cd_func(pfac,char *);
void ls_func(pnode_t,char*);
int crypt_ins(pfac,int,char*);
typedef struct{
	int len;
	char buf[1000];
}train;
#endif

