#include "func.h"

void getsalt(char *salt,char* passwd)
{
	int i,j;
	for(i=0,j=0;passwd[i]&&j!=3;i++)
	{
		if(passwd[i]=='$')
		{
			++j;
		}
	}
	strncpy(salt,passwd,i-1);
}


int crypt_func(int sfd,char* name)
{
	struct spwd *sp;
	char *passwd;
	char salt[512]={0};
	puts(name);
	passwd=getpass("请输入密码:");
	sp=getspnam(name);
	char *buf=NULL;
	if(NULL==sp)
	{
		perror("getspnam");
		return -1;
	}
	getsalt(salt,sp->sp_pwdp);
	buf=crypt(passwd,salt);
	send(sfd,buf,strlen(buf),0);
	return 0;

}
