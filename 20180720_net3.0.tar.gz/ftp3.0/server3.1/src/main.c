#include "factory.h"

int exit_fds[2];
void *thread_func(void *p)//子线程
{
	pfac pf=(pfac)p;
	pque_t pq=&pf->que;
	pnode_t pcur;
	char buf[128]={0};
	int ret;
	while(1)
	{
		pthread_mutex_lock(&pq->que_mutex);
		if(0==pq->size)
		{
			pthread_cond_wait(&pf->cond,&pq->que_mutex);
		}
		que_get(pq,&pcur);
		printf("I get pnode\n");
		pthread_mutex_unlock(&pq->que_mutex);
		int flag=0;
		if(pcur!=NULL)
		{
			while(1)
			{
				bzero(buf,sizeof(buf));
				ret=recv(pcur->new_fd,buf,sizeof(buf),0);
				if(flag==0)
				{
					memcpy(pf->name,buf,sizeof(buf));//这里把name定义成数组
					puts(pf->name);
					flag=1;
				}
				ins_func(pf,pcur,buf,strlen(buf));
				if(ret==0)
				{
					break;
				}
			}
			free(pcur);
		}
	}
}

void sig_exit_func(int signum)
{
	char flag=1;
	write(exit_fds[1],&flag,1);
}
int main(int argc,char **argv)
{
	if(argc!=2)
	{
		printf("./server THREAD_NUM");
		return -1;
	}
	pipe(exit_fds);
	if(fork())
	{
		close(exit_fds[0]);
		signal(SIGUSR1,sig_exit_func);
		pid_t pid;
		pid=wait(NULL);
		printf("pid=%d\n",pid);
		return 0;
	}
	close(exit_fds[1]);
	factory f;//主要数据结构
	int thread_num=atoi(argv[1]);
	int capacity=2000;
	factory_init(&f,thread_func,thread_num,capacity);
	factory_start(&f);
	int sfd;
	int new_fd;
	int ret;
	tcp_start_listen(&sfd,"192.168.200.128","2000",capacity);
	pque_t pq=&f.que;
	pnode_t pnew;
	int epfd=epoll_create(1);
	struct epoll_event event,evs[2];
	event.events=EPOLLIN;
	event.data.fd=sfd;
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
	check_error(-1,ret,"epoll_ctl");
	event.data.fd=exit_fds[0];
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,exit_fds[0],&event);
	check_error(-1,ret,"epoll_ctl1");
	int i;
	while(1)
	{
		ret=epoll_wait(epfd,evs,2,-1);
		for(i=0;i<ret;i++){
			if(sfd==evs[i].data.fd)
			{
				new_fd=accept(sfd,NULL,NULL);
				pnew=(pnode_t)calloc(1,sizeof(node_t));
				pnew->new_fd=new_fd;
				getcwd(f.path,sizeof(factory));
				printf("client is connect\n");
				pthread_mutex_lock(&pq->que_mutex);
				que_insert(pq,pnew);
				pthread_mutex_unlock(&pq->que_mutex);
				pthread_cond_signal(&f.cond);//发送信号给子线程
			}
			if(exit_fds[0]==evs[i].data.fd)
			{
				close(sfd);
				pnew=(pnode_t)calloc(1,sizeof(node_t));
				pnew->new_fd=-1;
				pthread_mutex_lock(&pq->que_mutex);
				que_insert_exit(pq,pnew);
				pthread_mutex_unlock(&pq->que_mutex);
				pthread_cond_broadcast(&f.cond);
				for(i=0;i<f.pthread_num;i++)
				{
					pthread_join(f.pth_id[i],NULL);
				}
				exit(0);
			}
		}
	}
}
