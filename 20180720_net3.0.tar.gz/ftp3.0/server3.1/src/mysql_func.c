#include "head.h"
/*
int mysql_delete(int argc,char* argv[])
{
	MYSQL *conn;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char* server="localhost";
	char* user="root";
	char* password="321";
	char* database="test25";
	char query[200]="delete from Person where LastName='san'";
	int t,r;
	conn=mysql_init(NULL);
	if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0))
	{
		printf("Error connecting to database:%s\n",mysql_error(conn));
	}else{
		printf("Connected...\n");
	}
	t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		if(mysql_affected_rows(conn))
		{
			printf("some rows affected\n");
		}else{
			printf("no rows match\n");
		}
	}
	mysql_close(conn);
	return 0;
}
*/
int mysql_insert(char *name,char *salt,char *cipher)
{
	MYSQL *conn;
	char* server="localhost";
	char* user="root";
	char* password="shadan1314";
	char* database="netdisk";
	char buf[512]={"/home/michael/netdisk/"};//路径名
	strcat(buf,name);
	char query[200]="insert into user(name,salt,cipher,path) values";
	sprintf(query,"%s(\"%s\",\"%s\",\"%s\",\"%s\")",query,name,salt,cipher,buf);
	puts(query);
	int t;
	conn=mysql_init(NULL);
	if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0))
	{
		printf("Error connecting to database:%s\n",mysql_error(conn));
	}else{
		printf("Connected...\n");
	}
	t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
		return -1;
	}else{
		printf("insert success\n");
	}
	mysql_close(conn);
	return 0;
}

/*
int mysql_update(int argc,char* argv[])
{
	if(argc!=2)
	{
		printf("error args\n");
		return -1;
	}
	MYSQL *conn;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char* server="localhost";
	char* user="root";
	char* password="123";
	char* database="test24";
	char query[200]="update Person set birthday='2018-03-19' where personID=";
	int personid=atoi(argv[1]);
	sprintf(query,"%s%d",query,personid);
	puts(query);
	int t,r;
	conn=mysql_init(NULL);
	if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0))
	{
		printf("Error connecting to database:%s\n",mysql_error(conn));
	}else{
		printf("Connected...\n");
	}
	t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
	}else{
		printf("update success\n");
	}
	mysql_close(conn);
	return 0;
}
*/

int mysql_Query(char *buf,char* name,char *tmp,int num)
{
	MYSQL *conn;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char* server="localhost";
	char* user="root";
	char* password="shadan1314";
	char* database="netdisk";//要访问的数据库名称
	char query[300]="select * from user where ";
	sprintf(query,"%s%s=\"%s\";",query,buf,name);
	puts(query);
	int t;
	conn=mysql_init(NULL);
	if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0))
	{
		printf("Error connecting to database:%s\n",mysql_error(conn));
		return -1;
	}else{
		printf("Connected...\n");
	}
	t=mysql_query(conn,query);
	if(t)
	{
		printf("Error making query:%s\n",mysql_error(conn));
		return -1;
	}else{
		res=mysql_use_result(conn);
		if(res)
		{

			row=mysql_fetch_row(res);
			memcpy(tmp,row[num],strlen(row[num]));
			printf("%8s\n",row[num]);
		}
		mysql_free_result(res);
	}
	mysql_close(conn);
	return 1;
}
