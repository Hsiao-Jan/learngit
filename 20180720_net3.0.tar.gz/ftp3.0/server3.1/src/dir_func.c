#include "factory.h"

void ls_func(pnode_t pq,char *qpath)
{
	if(qpath==NULL)
	{
		printf("error args");
		return;
	}
	DIR *dir;
	dir=opendir(qpath);
	if(dir==NULL)
	{
		perror("opendir");
		send(pq->new_fd,"error args",10,0);
	}
	struct dirent *p;
	struct stat tmp;
	char path[512]={0};
	char buf[512]={0};
	while((p=readdir(dir))!=NULL)
	{
		bzero(buf,sizeof(buf));
		sprintf(path,"%s%s%s",qpath,"/",p->d_name);
		stat(path,&tmp);
		if(!strcmp(p->d_name,".")||!strcmp(p->d_name,".."))
		{
		}else{
			sprintf(buf,"- %-25s%10ld\n",p->d_name,tmp.st_size);
			printf("%s",buf);
			send(pq->new_fd,buf,strlen(buf),0);
		}
	}
	closedir(dir);
}

void cd_func(pfac pf,char *qpath)
{
	int i=strlen(pf->path)-1;
	int len;
	char buf[512]={0};
	if(!strcmp(qpath,".."))
	{
		while(pf->path[i]!='/')
		{
			i--;
		}
		len=i;
		for(i=0;i<len;i++)
		{
			buf[i]=pf->path[i];
		}
		buf[i]='\0';
		printf("%s\n",buf);
		bzero(pf->path,sizeof(factory));
		memcpy(pf->path,buf,strlen(buf));	
	}else{
		strcat(pf->path,"/");
		strcat(pf->path,qpath);
	}	
}
/********************获取盐值**********************************/
void get_rand_str(char s[],int num)
{
	char *str="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";	
	int i,lstr;
	char ss[2]={0};
	lstr=strlen(str);
	srand((unsigned int)time((time_t *)NULL));
	for(i = 1; i <= num; i++)
	{
		sprintf(ss,"%c",str[(rand()%lstr)]);
		strcat(s,ss);
	}
}
void getsalt(char* salt)
{
	char s[9]={0};
	get_rand_str(s,8);
	strcat(salt,s);
}
int crypt_ins(pfac pf,int new_fd,char *buf)
{
	char cipher[100]={0};
	char salt[13]={"$6$"};
	char tmp[100]={0};//用于传递要查找的值，比如盐值，密文
	char flag[2]={0};
	if(strstr(buf,"1")!=NULL)
	{
		//表示用户选择了登录
		recv(new_fd,pf->name,sizeof(factory),0);//接用户名
		printf("name=%s\n",pf->name);
		mysql_Query("name",pf->name,tmp,2);//找盐值
		memcpy(salt,tmp,sizeof(tmp));
		printf("find_salt=%s\n",salt);
		send(new_fd,salt,strlen(salt),0);//发送盐值
		recv(new_fd,cipher,sizeof(cipher),0);//接收密文
		printf("recv_cip=%s\n",cipher);
		mysql_Query("name",pf->name,tmp,3);//找密文
		printf("find_cip=%s\n",tmp);
		if(strstr(tmp,cipher)!=NULL)
 	 	{
			printf("match successful\n");
			send(new_fd,"Login successful\n",18,0);
		}else{
			send(new_fd,"Login failed\n",14,0);
			while(1)
			{
				recv(new_fd,flag,sizeof(flag),0);
				if(strstr(flag,"1")!=NULL){
					send(new_fd,salt,strlen(salt),0);
					printf("tran salt\n");
				}
				recv(new_fd,cipher,sizeof(cipher),0);//接收密文
				printf("i recv\n");
				if(strstr(tmp,cipher)!=NULL)//密码输对了就出去
				{
					send(new_fd,"Login successful\n",18,0);
					break;
				}
				send(new_fd,"Login failed\n",14,0);//发送结果
			}
		}
		
	}else{
		//表示用户选择了注册，注册才需要生成盐值
		recv(new_fd,pf->name,sizeof(factory),0);//接用户名
		printf("name=%s\n",pf->name);
		getsalt(salt);
		send(new_fd,salt,strlen(salt),0);//发送盐值
		recv(new_fd,cipher,sizeof(cipher),0);//接收密文
		printf("cipher=%s\n",cipher);
		if(-1==mysql_insert(pf->name,salt,cipher))
		{
			send(new_fd,"Register failed\n",17,0);
		}else{
			send(new_fd,"Register successful\n",21,0);
		}
	}
	return 0;
}
