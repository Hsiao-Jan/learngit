#ifndef __WORK_QUE_H__
#define __WORK_QUE_H__
#include "head.h"
typedef struct tag_node{//队列元素
	int new_fd;
	struct tag_node* pNext;
}node_t,*pnode_t;

typedef struct{//队列数据结构
	pnode_t que_head,que_tail;
	int que_capacity;
	int size;
	pthread_mutex_t que_mutex;
}que_t,*pque_t;
void que_insert(pque_t,pnode_t);
void que_insert_exit(pque_t,pnode_t);
void que_get(pque_t,pnode_t*);
#endif
